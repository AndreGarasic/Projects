﻿namespace Seminar_Gr_E
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxPrikaz = new System.Windows.Forms.GroupBox();
            this.btnDohvati = new System.Windows.Forms.Button();
            this.labY = new System.Windows.Forms.Label();
            this.labX = new System.Windows.Forms.Label();
            this.labIndeks = new System.Windows.Forms.Label();
            this.txtYCord = new System.Windows.Forms.TextBox();
            this.txtXCord = new System.Windows.Forms.TextBox();
            this.txtIndeks = new System.Windows.Forms.TextBox();
            this.groupBoxMaxUdaljenost = new System.Windows.Forms.GroupBox();
            this.btnIzracunajMaxUdaljenost = new System.Windows.Forms.Button();
            this.labMaxUdalj = new System.Windows.Forms.Label();
            this.labIndeksDrugiMax = new System.Windows.Forms.Label();
            this.labIndeksPrviMax = new System.Windows.Forms.Label();
            this.txtMaxUdalj = new System.Windows.Forms.TextBox();
            this.txtJMax = new System.Windows.Forms.TextBox();
            this.txtIMax = new System.Windows.Forms.TextBox();
            this.groupBoxUdaljenost = new System.Windows.Forms.GroupBox();
            this.btnIzracunajUdalj = new System.Windows.Forms.Button();
            this.labUdaljenost = new System.Windows.Forms.Label();
            this.labY2 = new System.Windows.Forms.Label();
            this.labX2 = new System.Windows.Forms.Label();
            this.labY1 = new System.Windows.Forms.Label();
            this.labX1 = new System.Windows.Forms.Label();
            this.txtUdaljenost = new System.Windows.Forms.TextBox();
            this.txtY2 = new System.Windows.Forms.TextBox();
            this.txtY1 = new System.Windows.Forms.TextBox();
            this.txtX2 = new System.Windows.Forms.TextBox();
            this.txtX1 = new System.Windows.Forms.TextBox();
            this.Pomoc = new System.Windows.Forms.Button();
            this.groupBoxPrikaz.SuspendLayout();
            this.groupBoxMaxUdaljenost.SuspendLayout();
            this.groupBoxUdaljenost.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxPrikaz
            // 
            this.groupBoxPrikaz.Controls.Add(this.btnDohvati);
            this.groupBoxPrikaz.Controls.Add(this.labY);
            this.groupBoxPrikaz.Controls.Add(this.labX);
            this.groupBoxPrikaz.Controls.Add(this.labIndeks);
            this.groupBoxPrikaz.Controls.Add(this.txtYCord);
            this.groupBoxPrikaz.Controls.Add(this.txtXCord);
            this.groupBoxPrikaz.Controls.Add(this.txtIndeks);
            this.groupBoxPrikaz.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxPrikaz.Location = new System.Drawing.Point(12, 37);
            this.groupBoxPrikaz.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.groupBoxPrikaz.Name = "groupBoxPrikaz";
            this.groupBoxPrikaz.Padding = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.groupBoxPrikaz.Size = new System.Drawing.Size(260, 126);
            this.groupBoxPrikaz.TabIndex = 0;
            this.groupBoxPrikaz.TabStop = false;
            this.groupBoxPrikaz.Text = "Prikaz";
            // 
            // btnDohvati
            // 
            this.btnDohvati.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnDohvati.Location = new System.Drawing.Point(16, 79);
            this.btnDohvati.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnDohvati.Name = "btnDohvati";
            this.btnDohvati.Size = new System.Drawing.Size(77, 32);
            this.btnDohvati.TabIndex = 6;
            this.btnDohvati.Text = "Dohvati";
            this.btnDohvati.UseVisualStyleBackColor = true;
            this.btnDohvati.Click += new System.EventHandler(this.btnDohvati_Click);
            // 
            // labY
            // 
            this.labY.AutoSize = true;
            this.labY.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labY.Location = new System.Drawing.Point(184, 67);
            this.labY.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labY.Name = "labY";
            this.labY.Size = new System.Drawing.Size(15, 18);
            this.labY.TabIndex = 5;
            this.labY.Text = "Y";
            // 
            // labX
            // 
            this.labX.AutoSize = true;
            this.labX.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labX.Location = new System.Drawing.Point(182, 19);
            this.labX.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labX.Name = "labX";
            this.labX.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labX.Size = new System.Drawing.Size(16, 18);
            this.labX.TabIndex = 4;
            this.labX.Text = "X";
            // 
            // labIndeks
            // 
            this.labIndeks.AutoSize = true;
            this.labIndeks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labIndeks.Location = new System.Drawing.Point(29, 19);
            this.labIndeks.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labIndeks.Name = "labIndeks";
            this.labIndeks.Size = new System.Drawing.Size(49, 18);
            this.labIndeks.TabIndex = 3;
            this.labIndeks.Text = "Indeks";
            // 
            // txtYCord
            // 
            this.txtYCord.Location = new System.Drawing.Point(146, 88);
            this.txtYCord.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtYCord.Name = "txtYCord";
            this.txtYCord.Size = new System.Drawing.Size(89, 23);
            this.txtYCord.TabIndex = 2;
            // 
            // txtXCord
            // 
            this.txtXCord.Location = new System.Drawing.Point(146, 37);
            this.txtXCord.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtXCord.Name = "txtXCord";
            this.txtXCord.Size = new System.Drawing.Size(89, 23);
            this.txtXCord.TabIndex = 1;
            // 
            // txtIndeks
            // 
            this.txtIndeks.Location = new System.Drawing.Point(7, 37);
            this.txtIndeks.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtIndeks.Name = "txtIndeks";
            this.txtIndeks.Size = new System.Drawing.Size(93, 23);
            this.txtIndeks.TabIndex = 0;
            // 
            // groupBoxMaxUdaljenost
            // 
            this.groupBoxMaxUdaljenost.Controls.Add(this.btnIzracunajMaxUdaljenost);
            this.groupBoxMaxUdaljenost.Controls.Add(this.labMaxUdalj);
            this.groupBoxMaxUdaljenost.Controls.Add(this.labIndeksDrugiMax);
            this.groupBoxMaxUdaljenost.Controls.Add(this.labIndeksPrviMax);
            this.groupBoxMaxUdaljenost.Controls.Add(this.txtMaxUdalj);
            this.groupBoxMaxUdaljenost.Controls.Add(this.txtJMax);
            this.groupBoxMaxUdaljenost.Controls.Add(this.txtIMax);
            this.groupBoxMaxUdaljenost.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBoxMaxUdaljenost.Location = new System.Drawing.Point(12, 169);
            this.groupBoxMaxUdaljenost.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.groupBoxMaxUdaljenost.Name = "groupBoxMaxUdaljenost";
            this.groupBoxMaxUdaljenost.Padding = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.groupBoxMaxUdaljenost.Size = new System.Drawing.Size(260, 157);
            this.groupBoxMaxUdaljenost.TabIndex = 1;
            this.groupBoxMaxUdaljenost.TabStop = false;
            this.groupBoxMaxUdaljenost.Text = "Maksimalna udaljenost";
            // 
            // btnIzracunajMaxUdaljenost
            // 
            this.btnIzracunajMaxUdaljenost.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnIzracunajMaxUdaljenost.Location = new System.Drawing.Point(90, 22);
            this.btnIzracunajMaxUdaljenost.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnIzracunajMaxUdaljenost.Name = "btnIzracunajMaxUdaljenost";
            this.btnIzracunajMaxUdaljenost.Size = new System.Drawing.Size(74, 26);
            this.btnIzracunajMaxUdaljenost.TabIndex = 6;
            this.btnIzracunajMaxUdaljenost.Text = "Izračunaj";
            this.btnIzracunajMaxUdaljenost.UseVisualStyleBackColor = true;
            this.btnIzracunajMaxUdaljenost.Click += new System.EventHandler(this.btnIzracunajMaxUdaljenost_Click);
            // 
            // labMaxUdalj
            // 
            this.labMaxUdalj.AutoSize = true;
            this.labMaxUdalj.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labMaxUdalj.Location = new System.Drawing.Point(48, 105);
            this.labMaxUdalj.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labMaxUdalj.Name = "labMaxUdalj";
            this.labMaxUdalj.Size = new System.Drawing.Size(151, 18);
            this.labMaxUdalj.TabIndex = 5;
            this.labMaxUdalj.Text = "Maksimalna udaljenost";
            // 
            // labIndeksDrugiMax
            // 
            this.labIndeksDrugiMax.AutoSize = true;
            this.labIndeksDrugiMax.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labIndeksDrugiMax.Location = new System.Drawing.Point(146, 51);
            this.labIndeksDrugiMax.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labIndeksDrugiMax.Name = "labIndeksDrugiMax";
            this.labIndeksDrugiMax.Size = new System.Drawing.Size(88, 18);
            this.labIndeksDrugiMax.TabIndex = 4;
            this.labIndeksDrugiMax.Text = "Indeks druge";
            // 
            // labIndeksPrviMax
            // 
            this.labIndeksPrviMax.AutoSize = true;
            this.labIndeksPrviMax.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labIndeksPrviMax.Location = new System.Drawing.Point(13, 51);
            this.labIndeksPrviMax.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labIndeksPrviMax.Name = "labIndeksPrviMax";
            this.labIndeksPrviMax.Size = new System.Drawing.Size(80, 18);
            this.labIndeksPrviMax.TabIndex = 3;
            this.labIndeksPrviMax.Text = "Indeks prve";
            // 
            // txtMaxUdalj
            // 
            this.txtMaxUdalj.Location = new System.Drawing.Point(25, 126);
            this.txtMaxUdalj.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtMaxUdalj.Name = "txtMaxUdalj";
            this.txtMaxUdalj.Size = new System.Drawing.Size(197, 23);
            this.txtMaxUdalj.TabIndex = 2;
            // 
            // txtJMax
            // 
            this.txtJMax.Location = new System.Drawing.Point(146, 72);
            this.txtJMax.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtJMax.Name = "txtJMax";
            this.txtJMax.Size = new System.Drawing.Size(89, 23);
            this.txtJMax.TabIndex = 1;
            // 
            // txtIMax
            // 
            this.txtIMax.Location = new System.Drawing.Point(7, 72);
            this.txtIMax.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtIMax.Name = "txtIMax";
            this.txtIMax.Size = new System.Drawing.Size(93, 23);
            this.txtIMax.TabIndex = 0;
            // 
            // groupBoxUdaljenost
            // 
            this.groupBoxUdaljenost.Controls.Add(this.btnIzracunajUdalj);
            this.groupBoxUdaljenost.Controls.Add(this.labUdaljenost);
            this.groupBoxUdaljenost.Controls.Add(this.labY2);
            this.groupBoxUdaljenost.Controls.Add(this.labX2);
            this.groupBoxUdaljenost.Controls.Add(this.labY1);
            this.groupBoxUdaljenost.Controls.Add(this.labX1);
            this.groupBoxUdaljenost.Controls.Add(this.txtUdaljenost);
            this.groupBoxUdaljenost.Controls.Add(this.txtY2);
            this.groupBoxUdaljenost.Controls.Add(this.txtY1);
            this.groupBoxUdaljenost.Controls.Add(this.txtX2);
            this.groupBoxUdaljenost.Controls.Add(this.txtX1);
            this.groupBoxUdaljenost.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBoxUdaljenost.Location = new System.Drawing.Point(12, 332);
            this.groupBoxUdaljenost.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.groupBoxUdaljenost.Name = "groupBoxUdaljenost";
            this.groupBoxUdaljenost.Padding = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.groupBoxUdaljenost.Size = new System.Drawing.Size(260, 249);
            this.groupBoxUdaljenost.TabIndex = 2;
            this.groupBoxUdaljenost.TabStop = false;
            this.groupBoxUdaljenost.Text = "Udaljenost";
            // 
            // btnIzracunajUdalj
            // 
            this.btnIzracunajUdalj.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnIzracunajUdalj.Location = new System.Drawing.Point(86, 204);
            this.btnIzracunajUdalj.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnIzracunajUdalj.Name = "btnIzracunajUdalj";
            this.btnIzracunajUdalj.Size = new System.Drawing.Size(74, 27);
            this.btnIzracunajUdalj.TabIndex = 10;
            this.btnIzracunajUdalj.Text = "Izračunaj";
            this.btnIzracunajUdalj.UseVisualStyleBackColor = true;
            this.btnIzracunajUdalj.Click += new System.EventHandler(this.btnIzracunajUdalj_Click);
            // 
            // labUdaljenost
            // 
            this.labUdaljenost.AutoSize = true;
            this.labUdaljenost.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labUdaljenost.Location = new System.Drawing.Point(86, 154);
            this.labUdaljenost.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labUdaljenost.Name = "labUdaljenost";
            this.labUdaljenost.Size = new System.Drawing.Size(75, 18);
            this.labUdaljenost.TabIndex = 9;
            this.labUdaljenost.Text = "Udaljenost";
            // 
            // labY2
            // 
            this.labY2.AutoSize = true;
            this.labY2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labY2.Location = new System.Drawing.Point(180, 93);
            this.labY2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labY2.Name = "labY2";
            this.labY2.Size = new System.Drawing.Size(22, 18);
            this.labY2.TabIndex = 8;
            this.labY2.Text = "Y2";
            // 
            // labX2
            // 
            this.labX2.AutoSize = true;
            this.labX2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labX2.Location = new System.Drawing.Point(42, 93);
            this.labX2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labX2.Name = "labX2";
            this.labX2.Size = new System.Drawing.Size(23, 18);
            this.labX2.TabIndex = 7;
            this.labX2.Text = "X2";
            // 
            // labY1
            // 
            this.labY1.AutoSize = true;
            this.labY1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labY1.Location = new System.Drawing.Point(180, 39);
            this.labY1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labY1.Name = "labY1";
            this.labY1.Size = new System.Drawing.Size(22, 18);
            this.labY1.TabIndex = 6;
            this.labY1.Text = "Y1";
            // 
            // labX1
            // 
            this.labX1.AutoSize = true;
            this.labX1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labX1.Location = new System.Drawing.Point(42, 39);
            this.labX1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labX1.Name = "labX1";
            this.labX1.Size = new System.Drawing.Size(23, 18);
            this.labX1.TabIndex = 5;
            this.labX1.Text = "X1";
            // 
            // txtUdaljenost
            // 
            this.txtUdaljenost.Location = new System.Drawing.Point(32, 175);
            this.txtUdaljenost.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtUdaljenost.Name = "txtUdaljenost";
            this.txtUdaljenost.Size = new System.Drawing.Size(183, 23);
            this.txtUdaljenost.TabIndex = 4;
            // 
            // txtY2
            // 
            this.txtY2.Location = new System.Drawing.Point(146, 114);
            this.txtY2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtY2.Name = "txtY2";
            this.txtY2.Size = new System.Drawing.Size(89, 23);
            this.txtY2.TabIndex = 3;
            // 
            // txtY1
            // 
            this.txtY1.Location = new System.Drawing.Point(146, 58);
            this.txtY1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtY1.Name = "txtY1";
            this.txtY1.Size = new System.Drawing.Size(89, 23);
            this.txtY1.TabIndex = 2;
            // 
            // txtX2
            // 
            this.txtX2.Location = new System.Drawing.Point(6, 114);
            this.txtX2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtX2.Name = "txtX2";
            this.txtX2.Size = new System.Drawing.Size(93, 23);
            this.txtX2.TabIndex = 1;
            // 
            // txtX1
            // 
            this.txtX1.Location = new System.Drawing.Point(7, 58);
            this.txtX1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtX1.Name = "txtX1";
            this.txtX1.Size = new System.Drawing.Size(93, 23);
            this.txtX1.TabIndex = 0;
            // 
            // Pomoc
            // 
            this.Pomoc.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Pomoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Pomoc.ForeColor = System.Drawing.Color.Red;
            this.Pomoc.Location = new System.Drawing.Point(194, 8);
            this.Pomoc.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Pomoc.Name = "Pomoc";
            this.Pomoc.Size = new System.Drawing.Size(74, 23);
            this.Pomoc.TabIndex = 3;
            this.Pomoc.Text = "Pomoć";
            this.Pomoc.UseVisualStyleBackColor = false;
            this.Pomoc.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(290, 592);
            this.Controls.Add(this.Pomoc);
            this.Controls.Add(this.groupBoxUdaljenost);
            this.Controls.Add(this.groupBoxMaxUdaljenost);
            this.Controls.Add(this.groupBoxPrikaz);
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "Form1";
            this.Text = "Grupa E - udaljenosti";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxPrikaz.ResumeLayout(false);
            this.groupBoxPrikaz.PerformLayout();
            this.groupBoxMaxUdaljenost.ResumeLayout(false);
            this.groupBoxMaxUdaljenost.PerformLayout();
            this.groupBoxUdaljenost.ResumeLayout(false);
            this.groupBoxUdaljenost.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxPrikaz;
        private System.Windows.Forms.GroupBox groupBoxMaxUdaljenost;
        private System.Windows.Forms.GroupBox groupBoxUdaljenost;
        private System.Windows.Forms.Button btnDohvati;
        private System.Windows.Forms.Label labY;
        private System.Windows.Forms.Label labX;
        private System.Windows.Forms.Label labIndeks;
        private System.Windows.Forms.TextBox txtYCord;
        private System.Windows.Forms.TextBox txtXCord;
        private System.Windows.Forms.TextBox txtIndeks;
        private System.Windows.Forms.Button btnIzracunajMaxUdaljenost;
        private System.Windows.Forms.Label labMaxUdalj;
        private System.Windows.Forms.Label labIndeksDrugiMax;
        private System.Windows.Forms.Label labIndeksPrviMax;
        private System.Windows.Forms.TextBox txtMaxUdalj;
        private System.Windows.Forms.TextBox txtJMax;
        private System.Windows.Forms.TextBox txtIMax;
        private System.Windows.Forms.Button btnIzracunajUdalj;
        private System.Windows.Forms.Label labUdaljenost;
        private System.Windows.Forms.Label labY2;
        private System.Windows.Forms.Label labX2;
        private System.Windows.Forms.Label labY1;
        private System.Windows.Forms.Label labX1;
        private System.Windows.Forms.TextBox txtUdaljenost;
        private System.Windows.Forms.TextBox txtY2;
        private System.Windows.Forms.TextBox txtY1;
        private System.Windows.Forms.TextBox txtX2;
        private System.Windows.Forms.TextBox txtX1;
        private System.Windows.Forms.Button Pomoc;
    }
}

