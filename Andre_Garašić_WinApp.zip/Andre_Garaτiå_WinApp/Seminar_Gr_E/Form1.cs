﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Seminar_Gr_E
{
    public partial class Form1 : Form
    {
        string[,] matrica = new string[19864, 2];
        public Form1()
        {
            InitializeComponent();
            try
            {
                StreamReader ulaz = new StreamReader("podaciE.txt");
                while (!ulaz.EndOfStream)
                {
                    for (int i = 0; i < matrica.GetLength(0); i++)
                    {
                        string tekst = ulaz.ReadLine();
                        string[] x = tekst.Split(';');
                        matrica[i, 0] = x[0];
                        matrica[i, 1] = x[1];
                    }
                }
                MessageBox.Show("Podaci su učitani!");
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        private void btnDohvati_Click(object sender, EventArgs e)
        {
            
            if (txtIndeks.Text == "")
            {
                MessageBox.Show("Morate unijeti indeks!");
            }
            else
            {

                  
                    int dohvati = Convert.ToInt32(txtIndeks.Text);
           
            try
            {

                txtXCord.Text = matrica[dohvati, 0];
                txtYCord.Text = matrica[dohvati, 1];

            }
            catch (Exception)
            {

                MessageBox.Show("Unijeli ste neispravan indeks: " + dohvati + "!");
            }
             }
        }

        private void btnIzracunajUdalj_Click(object sender, EventArgs e)
        {
            if (txtX1.Text == ""&& txtX2.Text == "" && txtY1.Text == "" && txtY2.Text == "" )
            {
                MessageBox.Show("Morate unijeti koordinate!");
            }
            else
            {
            double X1 = Convert.ToDouble(txtX1.Text);
            double X2 = Convert.ToDouble(txtX2.Text);
            double Y1 = Convert.ToDouble(txtY1.Text);
            double Y2 = Convert.ToDouble(txtY2.Text);
            txtUdaljenost.Text = Convert.ToString(udaljenost(X1, X2, Y1, Y2) + "km");
            }
            

            
        }

        static double udaljenost(double X1, double X2, double Y1, double Y2)
        {
            return Math.Sqrt(Math.Pow(X1 - X2, 2) + Math.Pow(Y1 - Y2, 2)) ;

        }

        private void btnIzracunajMaxUdaljenost_Click(object sender, EventArgs e)
        {

            double d = 0;
            
            double max = 0;





            for (int i = 0; i < matrica.GetLength(0); i++)
            {
                double X1 = Convert.ToDouble(matrica[i, 0]);
                double Y1 = Convert.ToDouble(matrica[i, 1]);


                for (int j = 0; j < matrica.GetLength(0); j++)
                {
                    double X = Convert.ToDouble(matrica[j, 0]);
                    double Y = Convert.ToDouble(matrica[j, 1]);
                    d = udaljenost(X1, X, Y1, Y);

                    if (max < d)
                    {
                        max = d;
                        txtJMax.Text = Convert.ToString(j);
                        txtMaxUdalj.Text = Convert.ToString(max + "km");
                        txtIMax.Text = Convert.ToString(i);
                    }

                }

                
            }
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Prikaz: \nU polje Indeks Unosite broj indeksa od kojeg želite dohvatiti X i Y koordinate, kada ste unjeli željeni indeks pritisnite dugme Dohvati. \nMaksimalna Udaljenost: " +
                "\nAko želite doznati koja je maksimalna udaljenost između dvije koordinate onda pritisnite dugme Izračunaj te će se nakon nekoliko minuta izračunati maksimalna udaljenost te biti će prikazane njihove koordinate." +
                "\nUdaljenost: \nAko želite saznat udaljenost između bilo koje dvije koordinate samo unesite željene vrijednost X i Y koordinata te pritisnite dugme Izračunaj.");
        }
    }


}
 